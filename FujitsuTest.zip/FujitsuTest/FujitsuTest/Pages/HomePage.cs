﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;

namespace FujitsuTest.Pages
{
    public class HomePage
    {
        IWebDriver driver;

        public By logo = By.Id("header_logo");
        public By quickViewFirst = By.XPath("//*[@id='homefeatured']/li[1]/div/div[1]/div/a[1]/img");
        public By quickViewSecond = By.XPath("//*[@id='homefeatured']/li[2]/div/div[1]/div/a[1]/img");
        public By addToCart = By.Id("add_to_cart");
        public By dropDown = By.Id("group_1");
        public By Cart = By.XPath("//*[@id='header']/div[3]/div/div/div[3]/div/a");


        public HomePage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public void ClickOnElementByXpath(By element)
        {
            driver.FindElement(element).Click();
        }

        public void ClickOnElementByID(By element)
        {
            driver.FindElement(element).Click();
        }

        public void ClickOnPageLogo()
        {
            driver.FindElement(logo).Click();
        }

        public void ClickOnQuickViewFirst()
        {
            driver.FindElement(quickViewFirst).Click();

        }

        public void MouseOverOnElement()
        {
            Actions builder = new Actions(driver);
            builder.MoveToElement(driver.FindElement(quickViewFirst));
        }

        public void ClickOnQuickViewSecond()
        {
            driver.FindElement(quickViewSecond).Click();

        }

        public void MouseOverOnElement2()
        {
            Actions builder = new Actions(driver);
            builder.MoveToElement(driver.FindElement(quickViewSecond));
        }

        public void SelectFromDropDown()
        {
            SelectElement oSelect = new SelectElement(driver.FindElement(dropDown));
            oSelect.SelectByIndex(1);
        }

        public void AddToCart()
        {
            driver.FindElement(addToCart).Click();
        }

        public void ClickOnContinueShopping()
        {
            //driver.FindElement(By.XPath("//*[@id='layer_cart']/div[1]/div[2]/div[4]/a/span")).Click();
            driver.FindElement(By.ClassName("cross")).Click(); 
        }

        public string GetTextOfElement(String path)
        {
            return driver.FindElement(By.XPath(path)).Text;
        }

        public void ClickOnCart()
        {
            driver.FindElement(Cart).Click();
        }
    }
}
