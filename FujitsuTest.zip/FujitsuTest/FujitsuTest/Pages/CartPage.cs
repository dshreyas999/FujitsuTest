﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;

namespace FujitsuTest.Pages
{
    public class CartPage
    {
        IWebDriver driver;

        public By FirstProductPrice = By.XPath("//*[@id='product_price_1_3_413440']/span");
        public By SecondProductPrice = By.XPath("//*[@id='product_price_2_7_413440']/span");
        public By Total = By.XPath("//*[@id='total_price']");
        public By CS = By.XPath("//*[@id='center_column']/p[2]/a[1]/span");
        public By FirstContinue = By.XPath("//*[@id='center_column']/form/p/button");
        public By SecondContinue = By.XPath("//*[@id='uniform-cgv']");
        public By ThirdContinue = By.XPath("//*[@id='form']/p/button/span");
        public By FourthContinue = By.XPath("//*[@id='HOOK_PAYMENT']/div[1]/div/p/a");
        public By FifthContinue = By.XPath("//*[@id='cart_navigation']/button/span");
        public By Logout = By.ClassName("logout");

        public CartPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public string GetFirstProductPrice()
        {
            return driver.FindElement(FirstProductPrice).Text;
        }

        public string GetSecondProductPrice()
        {
            return driver.FindElement(SecondProductPrice).Text;
        }

        public string GetTotalProductPrice()
        {
            return driver.FindElement(Total).Text;
        }

        public void ClickOnContinueShopCartPage()
        {
            driver.FindElement(CS).Click();
        }

        public void ClickOnThisByXPath(By path)
        {
            driver.FindElement(path).Click();
        }

        public void ClickOnThisByClassName(By path)
        {
            driver.FindElement(path).Click();
        }
    }
}
