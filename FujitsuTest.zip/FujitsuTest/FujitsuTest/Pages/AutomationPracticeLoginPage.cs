using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;

namespace FujitsuTest
{    
    public class AutomationPracticeLoginPage
    {
        IWebDriver driver;

        By signIn = By.ClassName("login");
        By email = By.Id("email");
        By password = By.Id("passwd");
        By submit = By.Id("SubmitLogin");


        public AutomationPracticeLoginPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public void ClickOnSignIn()
        {
            driver.FindElement(signIn).Click();
        }

        public void SetEmailId(string Email)
        {
            driver.FindElement(email).SendKeys(Email);
        }

        public void SetPassword(string Password)
        {
            driver.FindElement(password).SendKeys(Password);
        }

        public void ClickOnSubmit()
        {
            driver.FindElement(submit).Click();
        }

        public void LoginToAutomatioonPractice(string emailId, string password)
        {
            ClickOnSignIn();
            SetEmailId("dshreyas999@gmail.com");
            SetPassword("FujitsuTest");
            ClickOnSubmit();
        }
    }
}
