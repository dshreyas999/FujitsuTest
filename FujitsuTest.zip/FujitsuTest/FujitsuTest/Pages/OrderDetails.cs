﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;

namespace FujitsuTest.Pages
{
    public class OrderDetails
    {

        IWebDriver driver;
        public By orderDetails = By.XPath("//*[@id='center_column']/div/div[1]/ul/li[1]/a/span");
        public By firstOrder = By.XPath("//*[@id='order-list']/tbody/tr[1]/td[7]/a[1]");
        public By dropDowm = By.XPath("//*[@id='sendOrderMessage']/p[2]/select");
        public By textMsg = By.XPath("//*[@id='sendOrderMessage']/p[3]/textarea");
        public By sendMsg = By.XPath("//*[@id='sendOrderMessage']/div/button/span");
        public By textAppear = By.XPath("//*[@id='block-order-detail']/div[5]/table/tbody/tr[1]/td[2]");
        public By logout = By.ClassName("logout");
        
        public OrderDetails(IWebDriver driver)
        {
            this.driver = driver;
        }

        public void ClickOnElementByXptah(By path)
        {
            driver.FindElement(path).Click();
        }

        public void ClickOnElementByClassName(By path)
        {
            driver.FindElement(path).Click();
        }

        public void SelectDropdown(By path)
        {
            SelectElement oSelect = new SelectElement(driver.FindElement(path));
            oSelect.SelectByIndex(1);
        }

        public void sendText(By path)
        {
            driver.FindElement(path).SendKeys("test");
        }

        public String GetText(By path)
        {
            return driver.FindElement(path).Text;
        }
    }
}
