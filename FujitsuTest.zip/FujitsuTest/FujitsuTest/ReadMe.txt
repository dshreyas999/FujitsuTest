﻿Hello,

- I have completed 3 test cases.
- I have used username: dshreyas999@gmail.com and password: FujitsuTest
- In the last i was facing issue with the login to the URL. I was getting error on browser : "Resource Limit Is Reached
The website is temporarily unable to service your request as it exceeded resource limit. Please try again later."
- I have implemented Page Object Model
- This framework has capabilities to take Screenshots and it will store it in Screenshots folder.
- This framework has capabilities to generate "Extent Report" for test cases
- Contact me @dshreyas999@gmail.com if you have any issues.