﻿using AventStack.ExtentReports;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace FujitsuTest.Utility
{
    class ExtentReporting
    {
        public static ExtentReports extent;
        public static ExtentTest exParentTest;
        public static ExtentTest exChildTest;
        public static string dirPath;

        public static void ReportLogger(string testCaseName)
        {
            extent = new ExtentReports();
            var dir = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase);
            dir = dir.Substring(6);
            Directory.CreateDirectory(dir + "\\Test_Execution_Report");
            
            dirPath = dir + "\\Test_Execution_Report\\Test_Execution_Report" + "_" + testCaseName;

            AventStack.ExtentReports.Reporter.ExtentHtmlReporter htmlReporter = new AventStack.ExtentReports.Reporter.ExtentHtmlReporter(dirPath);

            extent.AttachReporter(htmlReporter);
        }

    }
}
