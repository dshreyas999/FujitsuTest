﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace FujitsuTest.Utility
{
    class TakeScreenshot
    {
        IWebDriver driver;
        public TakeScreenshot(IWebDriver driver)
        {
            this.driver = driver;
        }

        public void TakeScreenshotInPng()
        {
            var path = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase);
            Console.WriteLine(path);
            path = path.Substring(6);
            Screenshot ss = ((ITakesScreenshot)driver).GetScreenshot();
            string screenshot = ss.AsBase64EncodedString;
            byte[] screenshotAsByteArray = ss.AsByteArray;
            ss.SaveAsFile(path + @"\..\..\..\Screenshots\Image.png", ScreenshotImageFormat.Png);
            ss.ToString();
        }
    }
}
