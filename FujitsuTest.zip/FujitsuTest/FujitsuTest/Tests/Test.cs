﻿using FujitsuTest.Pages;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using FujitsuTest.Utility;

namespace FujitsuTest.Tests
{
    [TestClass]
    public class Test
    {
        IWebDriver driver;
        public TestContext TestContext { get; set; }
        CartPage CP;
        HomePage hm;
        AutomationPracticeLoginPage login;
        OrderDetails OD;
        TakeScreenshot TS;
        String firstproductCost = "//*[@id='homefeatured']/li[1]/div/div[2]/div[1]/span";
        String secondproductCost = "//*[@id='homefeatured']/li[2]/div/div[2]/div[1]/span";
        String email = "dshreyas999@gmail.com";
        String pwd = "FujitsuTest";
        String sizeofFirst = "//*[@id='group_1']/option[2]";
        String sizeofSecond = "//*[@id='group_1']/option[1]";
        String totalCost = "$45.51";

        [TestInitialize]
        public void Setup()
        {
            driver = new ChromeDriver();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            driver.Navigate().GoToUrl("http://automationpractice.com/");
            driver.Manage().Window.Maximize();
        }

        [TestMethod]
        public void Test1()
        {
            try
            {
                ExtentReporting.ReportLogger(TestContext.TestName);
                ExtentReporting.exParentTest = ExtentReporting.extent.CreateTest(TestContext.TestName);
                ExtentReporting.exChildTest = ExtentReporting.exParentTest.CreateNode("Test 1");

                login = new AutomationPracticeLoginPage(driver);
                login.LoginToAutomatioonPractice(email, pwd);

                hm = new HomePage(driver);
                hm.ClickOnElementByID(hm.logo); //PageLogo
                string firstproductcost = hm.GetTextOfElement(firstproductCost);
                string secondproductcost = hm.GetTextOfElement(secondproductCost);
                hm.MouseOverOnElement();
                hm.ClickOnQuickViewFirst();
                driver.SwitchTo().Frame(1);
                hm.SelectFromDropDown();
                string sizeOfFirstProduct = hm.GetTextOfElement(sizeofFirst);
                hm.AddToCart();
                driver.SwitchTo().ParentFrame();
                hm.ClickOnContinueShopping();
                hm.MouseOverOnElement2();
                hm.ClickOnQuickViewSecond();
                driver.SwitchTo().Frame(1);
                string sizeOfSecondProduct = hm.GetTextOfElement(sizeofSecond);
                hm.AddToCart();
                driver.SwitchTo().ParentFrame();
                hm.ClickOnContinueShopping();
                hm.ClickOnCart();

                CP = new CartPage(driver);
                Assert.AreEqual(firstproductcost, CP.GetFirstProductPrice());
                Assert.AreEqual(secondproductcost, CP.GetSecondProductPrice());
                Assert.AreEqual(totalCost, CP.GetTotalProductPrice());
                CP.ClickOnContinueShopCartPage();
                CP.ClickOnThisByXPath(CP.FirstContinue);
                CP.ClickOnThisByXPath(CP.SecondContinue);
                CP.ClickOnThisByXPath(CP.ThirdContinue);
                CP.ClickOnThisByXPath(CP.FourthContinue);
                CP.ClickOnThisByXPath(CP.FifthContinue);
                CP.ClickOnThisByClassName(CP.Logout);
                ExtentReporting.exChildTest.Log(AventStack.ExtentReports.Status.Pass);
            }
            catch 
            {
                Assert.Fail();
                ExtentReporting.exChildTest.Log(AventStack.ExtentReports.Status.Fail);
            }

        }

        [TestMethod]
        public void Test2()
        {
            try
            {
                ExtentReporting.ReportLogger(TestContext.TestName);
                ExtentReporting.exParentTest = ExtentReporting.extent.CreateTest(TestContext.TestName);
                ExtentReporting.exChildTest = ExtentReporting.exParentTest.CreateNode("Test 2");
                
                login = new AutomationPracticeLoginPage(driver);
                login.LoginToAutomatioonPractice(email, pwd);

                OD = new OrderDetails(driver);
                OD.ClickOnElementByXptah(OD.orderDetails);
                OD.ClickOnElementByXptah(OD.firstOrder);
                OD.SelectDropdown(OD.dropDowm);
                OD.sendText(OD.textMsg);
                OD.ClickOnElementByXptah(OD.sendMsg);
                String textAppear = OD.GetText(OD.textAppear);
                Assert.AreEqual("test", textAppear);
                OD.ClickOnElementByClassName(OD.logout);
                ExtentReporting.exChildTest.Log(AventStack.ExtentReports.Status.Pass);
            }
            catch
            {
                Assert.Fail();
                ExtentReporting.exChildTest.Log(AventStack.ExtentReports.Status.Fail);
            }
        }

        [TestMethod]
        public void Test3()
        {
            TS = new TakeScreenshot(driver);

            try
            {
                ExtentReporting.ReportLogger(TestContext.TestName);
                ExtentReporting.exParentTest = ExtentReporting.extent.CreateTest(TestContext.TestName);
                ExtentReporting.exChildTest = ExtentReporting.exParentTest.CreateNode("Test 3");

                login = new AutomationPracticeLoginPage(driver);
                login.LoginToAutomatioonPractice(email, pwd);

                OD = new OrderDetails(driver);
                OD.ClickOnElementByXptah(OD.orderDetails);
                OD.ClickOnElementByXptah(OD.firstOrder);
                OD.SelectDropdown(OD.dropDowm);
                OD.sendText(OD.textMsg);
                OD.ClickOnElementByXptah(OD.sendMsg);
                String textAppear = OD.GetText(OD.textAppear);
                Assert.AreEqual("test1", textAppear);
                OD.ClickOnElementByClassName(OD.logout);
                ExtentReporting.exChildTest.Log(AventStack.ExtentReports.Status.Pass);
            }
            catch
            {
                ExtentReporting.exChildTest.Log(AventStack.ExtentReports.Status.Fail);
                TS.TakeScreenshotInPng();
                Assert.Fail();
            }
        }

        [TestCleanup]
        public void TestClean()
        {
            driver.Close();
            driver.Quit();
            ExtentReporting.extent.Flush();
        }


    }
}
